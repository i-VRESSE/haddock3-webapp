################################################################################
# Information about configuration files present in the same directory #
################################################################################
"output/data/configurations/raw_input.toml": An untouched copy of the raw input file, as provided by the user.
"output/data/configurations/cleaned_input.toml": Pre-parsed input file where (eventually) some indexing and modifications were applied to ensure further processing.
"output/data/configurations/enhanced_haddock_params.toml": Final input file with detailed default parameters.
